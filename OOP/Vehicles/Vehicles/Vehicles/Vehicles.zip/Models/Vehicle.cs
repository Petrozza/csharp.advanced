﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles.Models
{
    public abstract class Vehicle
    {
        private double fuelQuantity;
        private double fuelConsumption;

        protected Vehicle(double fuelQuantity, double fuelConsumption)
        {
            FuelQuantity = fuelQuantity;
            FuelConsumption = fuelConsumption;
        }

        public double FuelQuantity
        {
            get { return fuelQuantity; }
            private set { fuelQuantity = value; }
        }

        public double FuelConsumption
        {
            get { return fuelConsumption; }
            protected set { fuelConsumption = value; }
        }

        public bool Drive(double distance)
        {
            bool canDrive = FuelQuantity - FuelConsumption * distance >= 0;
            
            if (canDrive)
            {
                FuelQuantity -= FuelConsumption * distance;
                return true;
            }
            return false;
        }

        public virtual void Refuel(double fuel)
        {
            FuelQuantity += fuel;
        }

    }

}
