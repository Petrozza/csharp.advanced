﻿using System;
using System.Collections.Generic;
using System.Text;
using Vehicles.Models;

namespace Vehicles.Core
{
    public class Engine
    {
        public void Run()
        {
            string[] carInfo = Console.ReadLine().Split();
            string[] truckInfo = Console.ReadLine().Split();

            double carFuelQuantity = double.Parse(carInfo[1]);
            double carFuelConsumption = double.Parse(carInfo[2]);

            double truckFuelQuantity = double.Parse(truckInfo[1]);
            double truckFuelConsumption = double.Parse(truckInfo[2]);

            var car = new Car(carFuelQuantity, carFuelConsumption);
            var truck = new Truck(truckFuelQuantity, truckFuelConsumption);

            int count = int.Parse(Console.ReadLine());

            for (int i = 0; i < count; i++)
            {
                string[] inputInfo = Console.ReadLine().Split();

                string command = inputInfo[0];
                string vehickeType = inputInfo[1];
                double value = double.Parse(inputInfo[2]);

                if (command == "Drive")
                {
                    if (vehickeType == "Car")
                    {
                        DriveVehicle(car, value);
                    }
                    else if (vehickeType == "Truck")
                    {
                        DriveVehicle(truck, value);
                    }
                }
                else if (command == "Refuel")
                {
                    if (vehickeType == "Car")
                    {
                        car.Refuel(value);
                    }
                    else if (vehickeType == "Truck")
                    {
                        truck.Refuel(value);
                    }
                }
            }

            Console.WriteLine($"Car: {car.FuelQuantity:f}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:f}");
        }

        private static void DriveVehicle(Vehicle vehicle, double value)
        {
            bool canTravell = vehicle.Drive(value);

            string result = !canTravell
                ? $"{vehicle.GetType().Name} needs refueling"
                : $"{vehicle.GetType().Name} travelled {value} km";
            Console.WriteLine(result);
        }
    }
}
