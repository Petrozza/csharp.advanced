﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingSpree.Common
{
    public static class GlobalConstatnts
    {
        public const string EmptyNameExcMsg = "Name cannot be empty";
        public const string NegativeMoneyMsg = "Money cannot be negative";
    }
}
