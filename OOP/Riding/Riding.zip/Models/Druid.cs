﻿
namespace Riding.Models
{
    public class Druid : BaseHero
    {
        public Druid(string name) 
            : base(name, 80)
        {
        }
    }
}
