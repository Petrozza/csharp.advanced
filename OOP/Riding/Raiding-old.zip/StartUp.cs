﻿using System;
using System.Collections.Generic;

namespace Riding
{
    public class StartUp
    {
        public static void Main()
        {
            Engine engine = new Engine();
            engine.Run();

            
        }
    }
}
