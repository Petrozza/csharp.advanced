﻿
namespace Riding
{
    public class Druid : BaseHero
    {
        public Druid(string name) 
            : base(name, 80)
        {
        }
    }
}
