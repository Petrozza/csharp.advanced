﻿
namespace Wild.Farm.Models.Foods
{
    public class Fruit : Food
    {
        public Fruit(int quantity) 
            : base(quantity)
        {
        }
    }
}
