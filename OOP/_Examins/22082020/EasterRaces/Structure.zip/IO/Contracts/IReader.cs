﻿namespace EasterRaces.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
