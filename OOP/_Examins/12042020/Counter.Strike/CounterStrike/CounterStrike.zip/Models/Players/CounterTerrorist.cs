﻿using CounterStrike.Models.Guns.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace CounterStrike.Models.Players
{
    class CounterTerrorist : Player
    {
        protected CounterTerrorist(string username, int health, int armor, IGun gun, bool isAlive) 
            : base(username, health, armor, gun, isAlive)
        {
        }
    }
}
