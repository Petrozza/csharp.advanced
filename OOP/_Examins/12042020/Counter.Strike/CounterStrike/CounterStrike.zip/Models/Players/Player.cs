﻿using CounterStrike.Models.Guns.Contracts;
using CounterStrike.Models.Players.Contracts;
using CounterStrike.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Text;

namespace CounterStrike.Models.Players
{
    public abstract class Player : IPlayer
    {
        private string name;
        private int health;
        private int armor;
        private IGun gun;

        protected Player(string username, int health, int armor, IGun gun, bool isAlive)
        {
            Username = username;
            Health = health;
            Armor = armor;
            Gun = gun;
            //IsAlive = isAlive;
        }

        public string Username 
        {
            get
            {
                return name;
            }
            private set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException(ExceptionMessages.InvalidPlayerName);
                }
                name = value;
            }
        }
        public int Health
        {
            get
            {
                return health;
            }
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException(ExceptionMessages.InvalidPlayerHealth);
                }

                health = value;
            }
        }
        public int Armor 
        {
            get
            {
                return armor;
            }
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException(ExceptionMessages.InvalidPlayerArmor);
                }
                armor = value;
            }
        }
        public IGun Gun
        {
            get
            {
                return gun;
            }
            private set
            {
                if (value == null)
                {
                    throw new ArgumentException(ExceptionMessages.InvalidGun);
                }
                gun = value;
            }
        }
        public bool IsAlive => Health > 0;

        public void TakeDamage(int points)
        {
            if (Armor > 0)
            {
                Armor -= points;

                if (Armor < 0)
                {
                    Health -= Armor * -1;
                    Armor = 0;
                }
            }
            else
            {
                Health -= points;
            }
        }
    }
}
