﻿using System;
using System.Collections.Generic;
using System.Text;

public interface ISpecialisedSoldier : IPrivate
{
    string Corps { get; }
}