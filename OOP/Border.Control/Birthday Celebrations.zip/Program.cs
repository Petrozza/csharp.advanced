﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Border.Control
{
    public class Program
    {
        public static void Main(string[] args)
        {
            List<IBirthable> dates = new List<IBirthable>();
            string input = Console.ReadLine();
            while (input != "End")
            {
                string[] commandArg = input.Split();
                if (commandArg[0] == "Citizen")
                {
                    string nameCitizen = commandArg[1];
                    int ages = int.Parse(commandArg[2]);
                    string idNumber = commandArg[3];
                    string bisthCitizen = commandArg[4];
                    dates.Add(new Citizen(nameCitizen, ages, idNumber, bisthCitizen));

                }
                else if (commandArg[0] == "Pet")
                {
                    string petName = commandArg[1];
                    string petBirthdate = commandArg[2];
                    dates.Add(new Pet(petName, petBirthdate));
                }

                else if (commandArg[0] == "Robot")
                {
                    input = Console.ReadLine();
                    continue;
                }

                input = Console.ReadLine();
            }

            string year = Console.ReadLine();

            foreach (var records in dates)
            {
                if (records.Birthdate.EndsWith(year))
                {
                    Console.WriteLine(records.Birthdate);
                }
            }
        }
    }
}
