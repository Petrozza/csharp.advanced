﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Border.Control
{
    interface IBirthable
    {
        string Birthdate { get;  }
    }
}
