﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Border.Control
{
    interface INaming
    {
        string Name { get; }
    }
}
