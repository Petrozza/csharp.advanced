﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Border.Control
{
    public class Citizen : IIdentified
    {
        public Citizen(string name, int Age, string id)
        {
            Id = id;
        }
        public string Id { get;  }


    }
}
