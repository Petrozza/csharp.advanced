﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Border.Control
{
    public class Program
    {
        public static void Main(string[] args)
        {
            List<string> ids = new List<string>();
            string input = Console.ReadLine();
            while (input != "End")
            {
                string[] commandArg = input.Split();
                if (commandArg.Count() == 3)
                {
                    string nameCitizen = commandArg[0];
                    int ages = int.Parse(commandArg[1]);
                    string idNumber = commandArg[2];
                    Citizen citizen = new Citizen(nameCitizen, ages, idNumber);
                    ids.Add(citizen.Id);

                }
                else if (commandArg.Count() == 2)
                {
                    string modelRobot = commandArg[0];
                    string idRobot = commandArg[1];
                    Robot robot = new Robot(modelRobot, idRobot);
                    ids.Add(idRobot);
                }

                input = Console.ReadLine();
            }

            string fakeId = Console.ReadLine();
            foreach (var id in ids)
            {
                if (id.Substring(id.Length - fakeId.Length) == fakeId)
                {
                    Console.WriteLine(id);
                }
            }
        }
    }
}
