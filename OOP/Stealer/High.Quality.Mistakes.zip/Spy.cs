﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Stealer
{
    public class Spy
    {
        public string StealFieldInfo(string investigateClass, params string[] investigteFields)
        {
            var type = Type.GetType(investigateClass);
            var neededFields = type.GetFields(BindingFlags.Instance | BindingFlags.Public
                | BindingFlags.NonPublic | BindingFlags.Static);

            StringBuilder sb = new StringBuilder();

            var hackerInstance = Activator.CreateInstance(type, new object[] { });
            sb.AppendLine($"Class under investigation: {investigateClass}");

            foreach (var field in neededFields.Where(f => investigteFields.Contains(f.Name)))
            {
                sb.AppendLine($"{field.Name} = {field.GetValue(hackerInstance)}");
            }

            return sb.ToString().Trim();
        }

        public string AnalyzeAcessModifiers(string className)
        {
            var invClassType = Type.GetType(className);
            var invFileds = invClassType.GetFields(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public);
            var classPublicMethods = invClassType.GetMethods(BindingFlags.Instance | BindingFlags.Public) ;
            var classNonPublicMethods = invClassType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic);

            StringBuilder bb = new StringBuilder();

           // Object hackerInstance = Activator.CreateInstance(invClassType, new object[] { });

            foreach (FieldInfo field in invFileds)
            {
                bb.AppendLine($"{field.Name} must be private!");
            }

            foreach (MethodInfo method in classNonPublicMethods.Where(m => m.Name.StartsWith("get")))
            {
                bb.AppendLine($"{method.Name} have to be public!");
            }

            foreach (MethodInfo method in classPublicMethods.Where(m => m.Name.StartsWith("set")))
            {
                bb.AppendLine($"{method.Name} have to be private!");
            }

            return bb.ToString().Trim();
        }

    }
}
