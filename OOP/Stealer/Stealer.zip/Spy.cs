﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Stealer
{
    public class Spy
    {
        public string StealFieldInfo(string investigateClass, params string[] investigteFields)
        {
            var type = Type.GetType(investigateClass);
            var neededFields = type.GetFields(BindingFlags.Instance | BindingFlags.Public
                | BindingFlags.NonPublic | BindingFlags.Static);

            StringBuilder sb = new StringBuilder();

            var hackerInstance = Activator.CreateInstance(type, new object[] { });
            sb.AppendLine($"Class under investigation: {investigateClass}");

            foreach (var field in neededFields.Where(f => investigteFields.Contains(f.Name)))
            {
                sb.AppendLine($"{field.Name} = {field.GetValue(hackerInstance)}");
            }

            return sb.ToString().Trim();
        }

    }
}
