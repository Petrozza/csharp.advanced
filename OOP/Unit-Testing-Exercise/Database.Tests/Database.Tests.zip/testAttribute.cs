﻿using System;

namespace Tests
{
    internal class testAttribute : Attribute
    {
    }
}