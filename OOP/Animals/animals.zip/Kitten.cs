﻿
namespace Animals
{
    public class Kitten
    {
    }
}
