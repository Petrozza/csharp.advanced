﻿
namespace Animals
{
    class Tomcat
    {
    }
}
