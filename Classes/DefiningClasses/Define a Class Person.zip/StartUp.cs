﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var person = new Person();
            person.Name = "Pesho";
            person.Age = 20;

            Console.WriteLine($"{person.Name}, {person.Age}");
        }
    }
}
