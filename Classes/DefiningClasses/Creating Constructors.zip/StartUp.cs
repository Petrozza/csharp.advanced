﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string name = "Pesho";
            int age = 20;
            var person = new Person(name, age);

            Console.WriteLine($"{person.Name}, {person.Age}");
        }
    }
}
